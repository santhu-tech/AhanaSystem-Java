package com.training.demo._hibernate_demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="Sample Table")
public class Employee {
	@Id
	private int Emp_id;
	private String Emp_dept;
	private EmployeeName_Details Emp_Name;
	
	public int getEmp_id() {
		return Emp_id;
	}
	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}
	public String getEmp_dept() {
		return Emp_dept;
	}
	public void setEmp_dept(String emp_dept) {
		Emp_dept = emp_dept;
	}
	public EmployeeName_Details getEmp_Name() {
		return Emp_Name;
	}
	public void setEmp_Name(EmployeeName_Details emp_Name) {
		Emp_Name = emp_Name;
	}
	@Override
	public String toString() {
		return "Employee [Emp_id=" + Emp_id + ", Emp_dept=" + Emp_dept + ", Emp_Name=" + Emp_Name + "]";
	}
	
	
	


}
