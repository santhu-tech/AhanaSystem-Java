package com.training.demo._hibernate_demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class App {
	public static void main( String[] args )
    {
    	
		
		//create configuration
    	Configuration configuration=new Configuration();
    	configuration.configure("hibernate.cfg.xml");
    	//create session factory
    	SessionFactory sessionFactory= configuration.buildSessionFactory();                      //design factory 
    	
    	//initialize the session object
    	Session session=sessionFactory.openSession();
    	
    	EmployeeName_Details employeename=new EmployeeName_Details();
    	employeename.setFirst_name("P");
    	employeename .setMiddle_name("Santhiya");
    	employeename .setLast_name("Kowsi");
    	
    	
    	Employee emp1=new Employee();
    	emp1.setEmp_id(1);
    	emp1.setEmp_dept("FullStack");
    	emp1.setEmp_Name(employeename);
    	
    	session.beginTransaction();
    	session.save(emp1);  //Persist ,merge,update 
    	session.getTransaction().commit();
    	
    	System.out.println("Saved employee details to db");
    	
       
    }
}
