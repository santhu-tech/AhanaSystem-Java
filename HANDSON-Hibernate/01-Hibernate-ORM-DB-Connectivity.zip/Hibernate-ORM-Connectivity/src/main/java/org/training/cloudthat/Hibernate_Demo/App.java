package org.training.cloudthat.Hibernate_Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class App 
{
    
	
	public static void main( String[] args ) {
    
		
		
		Configuration Configuration=new Configuration();
		Configuration.configure("hibernate.cfg.xml");
		Configuration.addAnnotatedClass(Employee.class);
		SessionFactory sessionFactory=Configuration.buildSessionFactory();
    	Session session=sessionFactory.openSession();
    	Employee Emp1=new Employee();
    	Emp1.setEmp_id(1);
    	Emp1.setEmp_name("santhiya");
    	Emp1.setEmp_domain("Java");
    	session.beginTransaction();
    	session.persist(Emp1);
    	session.getTransaction().commit();
    	System.out.println("Saved");
    	
    	
    	
    }
}
