package org.training.cloudthat.Hibernate_Demo;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Employee { //tablename

	@Id
		private int Emp_id;
		private String Emp_name;
	    private	String Emp_dept;
	public int getEmp_id() {
		return Emp_id;
	}
	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}
	public String getEmp_name() {
		return Emp_name;
	}
	public void setEmp_name(String emp_name) {
		Emp_name = emp_name;
	}
	public String getEmp_dept() {
		return Emp_dept;
	}
	public void setEmp_domain(String emp_dept) {
		Emp_dept = emp_dept;
	}
	@Override
	public String toString() {
		return "Employee [Emp_id=" + Emp_id + ", Emp_name=" + Emp_name + ", Emp_dept=" + Emp_dept + "]";
	}

	}


